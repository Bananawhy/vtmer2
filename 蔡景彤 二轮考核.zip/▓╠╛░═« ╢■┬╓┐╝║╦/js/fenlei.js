
Vue.config.productionTip = false
require('./mock')
/* eslint-disable no-new */
new Vue({
  el: '#ap',
  router,
  components: { Ap },
  template: '<Ap/>'
})

axios.get('/data/index', {            
    params: {}        
}).then(res => {            
    console.log(res);        
}).catch(err => {            
                
});



    /**
     *
     * @param id  传入元素的id
     * @returns {HTMLElement | null}  返回标签对象，方便获取元素
     */
    function close(){
        document.getElementById("details").style.display="none";
    }
    function my$(id) {
        return document.getElementById(id);
    }
 
    //获取各元素，方便操作
    var box=my$("box");
    var inner=box.children[0];
    var ulObj=inner.children[0];
    var list=ulObj.children;
    var olObj=inner.children[1];
    var arr=my$("arr");
    var imgWidth=inner.offsetWidth;
    var right=my$("right");
    var pic=0;
    //根据li个数，创建小按钮
    for(var i=0;i<list.length;i++){
        var liObj=document.createElement("li");
 
        olObj.appendChild(liObj);
        liObj.setAttribute("index",i);
 
        //为按钮注册mouseover事件
        liObj.onmouseover=function () {
            //先清除所有按钮的样式
 
            for (var j=0;j<olObj.children.length;j++){
                olObj.children[j].removeAttribute("class");
            }
            this.className="current";
            pic=this.getAttribute("index");
            animate(ulObj,-pic*imgWidth);
        }
 
    }
 
 <script>
    //设置ol中第一个li有背景颜色
    olObj.children[0].className = "current";
    //克隆一个ul中第一个li,加入到ul中的最后=====克隆
    ulObj.appendChild(ulObj.children[0].cloneNode(true));
 
    var timeId=setInterval(onmouseclickHandle,2500);
    //左右焦点实现点击切换图片功能
    box.onmouseover=function () {
        arr.style.display="block";
        clearInterval(timeId);
    };
    box.onmouseout=function () {
        arr.style.display="none";
        timeId=setInterval(onmouseclickHandle,1000);
    };
 
    right.onclick=onmouseclickHandle;
    function onmouseclickHandle() {
        //如果pic的值是5,恰巧是ul中li的个数-1的值,此时页面显示第六个图片,而用户会认为这是第一个图,
        //所以,如果用户再次点击按钮,用户应该看到第二个图片
        if (pic == list.length - 1) {
            //如何从第6个图,跳转到第一个图
            pic = 0;//先设置pic=0
            ulObj.style.left = 0 + "px";//把ul的位置还原成开始的默认位置
        }
        pic++;//立刻设置pic加1,那么此时用户就会看到第二个图片了
        animate(ulObj, -pic * imgWidth);//pic从0的值加1之后,pic的值是1,然后ul移动出去一个图片
        //如果pic==5说明,此时显示第6个图(内容是第一张图片),第一个小按钮有颜色,
        if (pic == list.length - 1) {
            //第五个按钮颜色干掉
            olObj.children[olObj.children.length - 1].className = "";
            //第一个按钮颜色设置上
            olObj.children[0].className = "current";
        } else {
            //干掉所有的小按钮的背景颜色
            for (var i = 0; i < olObj.children.length; i++) {
                olObj.children[i].removeAttribute("class");
            }
            olObj.children[pic].className = "current";
        }
    }
    left.onclick=function () {
        if (pic==0){
            pic=list.length-1;
            ulObj.style.left=-pic*imgWidth+"px";
        }
        pic--;
        animate(ulObj,-pic*imgWidth);
        for (var i = 0; i < olObj.children.length; i++) {
            olObj.children[i].removeAttribute("class");
        }
        //当前的pic索引对应的按钮设置颜色
        olObj.children[pic].className = "current";
    };
 
    //设置任意的一个元素,移动到指定的目标位置
    function animate(element, target) {
        clearInterval(element.timeId);
        //定时器的id值存储到对象的一个属性中
        element.timeId = setInterval(function () {
            //获取元素的当前的位置,数字类型
            var current = element.offsetLeft;
            //每次移动的距离        
            var step = 150;
            step = current < target ? step : -step;
            //当前移动到位置
            current += step;                                                    
            if (Math.abs(current - target) > Math.abs(step)) {
                element.style.left = current + "px";
            } else {
                //清理定时器
                clearInterval(element.timeId);
                //直接到达目标
                element.style.left = target + "px";
            }
        }, 25);
    }
</script>


    
    var second = document.getElementsByClassName("active")
    var nextpage = document.getElementById("next");
    var prevpage = document.getElementById("prev");
    var pageTotal = "x";
    var pageTotal = 12;
 
    myFunction();
    function myFunction(){
        document.getElementById("demo").innerHTML = "第&nbsp" + pageTotal + "&nbsp页";}
        document.getElementById("last").innerHTML = pageTotal;

  

    function changepage(){
        document.getElementById("second").className="active";
        document.getElementById("first").className="notactive";
        document.getElementById("third").className="notactive";
        document.getElementById("middle").className="notactive";
    } 

     
    function changepage2(){
        document.getElementById("third").className="active";
        document.getElementById("second").className="notactive";
        document.getElementById("first").className="notactive";
        document.getElementById("middle").className="notactive";
    } 
    function changepage3(){
        document.getElementById("middle").className="active";
        document.getElementById("second").className="notactive";
        document.getElementById("first").className="notactive";
        document.getElementById("third").className="notactive";
    }
    function changepage4(){
        var x="";
        var i = "4";
        var li = document.querySelector.getElementById("middle");
        console.log(li.innerHTML.replace("i","i++").Math)
       
    }

        



var ap = new Vue({
  el:'#ap',
  data: {
 
    author:'@name()',
    message: 'Hello Vue.js!',
  }
})

    


  

//调用mock方法模拟数据
Mock.mock(
    'http://mockjs', {
                    //星级
                    'string|1-5': "★",
                    // 书名
                    title:'@title(1,5)',
          			// 作者
          			author:'@name()',
    }
);

//ajax请求
$("#mockjs").click(function(){
    $.ajax({
        url        : "http://mockjs",    //请求的url地址
        dataType   : "json",   //返回格式为json
        async      : true, //请求是否异步，默认为异步，这也是ajax重要特性
        data       : {},    //参数值
        type       : "post",   //请求方式
        beforeSend : function() {
            //请求前的处理
        },
        success: function(req) {
            //请求成功时处理
            console.log(req);
        },
        complete: function() {
            //请求完成的处理
        },
        error: function() {
            //请求出错处理
        }
    });
});

$.ajax({
    url: 'http://test.com',
    type: '',
    dataType: 'json',
    data: {
      account: 888,
      pwd: 'abc123'
    }
}).done(function(data, status, xhr) {
    console.log(JSON.stringify(data, null, 4));
});
       
    