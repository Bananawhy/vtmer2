//轮播图

    /**
     *
     * @param id  传入元素的id
     * @returns {HTMLElement | null}  返回标签对象，方便获取元素
     */
    function close(){
        document.getElementById("details").style.display="none";
    }
    function my$(id) {
        return document.getElementById(id);
    }
 
    //获取各元素，方便操作
    var box=my$("box");
    var inner=box.children[0];
    var ulObj=inner.children[0];
    var list=ulObj.children;
    var olObj=inner.children[1];
    var arr=my$("arr");
    var imgWidth=inner.offsetWidth;
    var right=my$("right");
    var pic=0;
    //根据li个数，创建小按钮
    for(var i=0;i<list.length;i++){
        var liObj=document.createElement("li");
 
        olObj.appendChild(liObj);
        liObj.setAttribute("index",i);
 
        //为按钮注册mouseover事件
        liObj.onmouseover=function () {
            //先清除所有按钮的样式
 
            for (var j=0;j<olObj.children.length;j++){
                olObj.children[j].removeAttribute("class");
            }
            this.className="current";
            pic=this.getAttribute("index");
            animate(ulObj,-pic*imgWidth);
        }
 
    }
 
 
    //设置ol中第一个li有背景颜色
    olObj.children[0].className = "current";
    //克隆一个ul中第一个li,加入到ul中的最后=====克隆
    ulObj.appendChild(ulObj.children[0].cloneNode(true));
 
    var timeId=setInterval(onmouseclickHandle,2500);
    //左右焦点实现点击切换图片功能
    box.onmouseover=function () {
        arr.style.display="block";
        clearInterval(timeId);
    };
    box.onmouseout=function () {
        arr.style.display="none";
        timeId=setInterval(onmouseclickHandle,1000);
    };
 
    right.onclick=onmouseclickHandle;
    function onmouseclickHandle() {
        //如果pic的值是5,恰巧是ul中li的个数-1的值,此时页面显示第六个图片,而用户会认为这是第一个图,
        //所以,如果用户再次点击按钮,用户应该看到第二个图片
        if (pic == list.length - 1) {
            //如何从第6个图,跳转到第一个图
            pic = 0;//先设置pic=0
            ulObj.style.left = 0 + "px";//把ul的位置还原成开始的默认位置
        }
        pic++;//立刻设置pic加1,那么此时用户就会看到第二个图片了
        animate(ulObj, -pic * imgWidth);//pic从0的值加1之后,pic的值是1,然后ul移动出去一个图片
        //如果pic==5说明,此时显示第6个图(内容是第一张图片),第一个小按钮有颜色,
        if (pic == list.length - 1) {
            //第五个按钮颜色干掉
            olObj.children[olObj.children.length - 1].className = "";
            //第一个按钮颜色设置上
            olObj.children[0].className = "current";
        } else {
            //干掉所有的小按钮的背景颜色
            for (var i = 0; i < olObj.children.length; i++) {
                olObj.children[i].removeAttribute("class");
            }
            olObj.children[pic].className = "current";
        }
    }
    left.onclick=function () {
        if (pic==0){
            pic=list.length-1;
            ulObj.style.left=-pic*imgWidth+"px";
        }
        pic--;
        animate(ulObj,-pic*imgWidth);
        for (var i = 0; i < olObj.children.length; i++) {
            olObj.children[i].removeAttribute("class");
        }
        //当前的pic索引对应的按钮设置颜色
        olObj.children[pic].className = "current";
    };
 
    //设置任意的一个元素,移动到指定的目标位置
    function animate(element, target) {
        clearInterval(element.timeId);
        //定时器的id值存储到对象的一个属性中
        element.timeId = setInterval(function () {
            //获取元素的当前的位置,数字类型
            var current = element.offsetLeft;
            //每次移动的距离        
            var step = 150;
            step = current < target ? step : -step;
            //当前移动到位置
            current += step;                                                    
            if (Math.abs(current - target) > Math.abs(step)) {
                element.style.left = current + "px";
            } else {
                //清理定时器
                clearInterval(element.timeId);
                //直接到达目标
                element.style.left = target + "px";
            }
        }, 25);
    }




//分页半成品

        var ul = document.getElementById('pagination');
        var li = pagination.getElementsByTagName('li');
        li[2].className = 'background';
        var num01 = 1;
        var num02 = 12/*总数*/;

var num3;
//3 //上一页的点击事件
            li[li.length-(li.length-1)].onclick = function(){

                for(var j = 0;j<li.length-4;j++){
                    if(li[j+2].className == 'background' && li[j+2].innerHTML != 1){
                        if(j+2 != li.length-(li.length-2)){
                            document.getElementById("demo").innerHTML = "第&nbsp" + j + "&nbsp页";
                            Background(j+1);
                        }
                        break;
                    }
                }
                if(j+2 == li.length-(li.length-2)){
                    num01 -- ;
                    content(num01);
                    
                }
            }
//4 下一页的点击事件
            li[li.length-2].onclick = function(){
                for(var j = 0;j<li.length;j++){
                    if(li[j].className == 'background' && li[j].innerHTML < num02){  //* && 写最后一页的总数*/
                        if(j+1 < li.length-2){
                            Background(j+1);
                            document.getElementById("demo").innerHTML = "第&nbsp" + j + "&nbsp页";
                            
                        }
                        break;
                    }
                }
                if(j+1 == li.length-2){
                    num01++;
                    content(num01);
                }
            }        
//     分页的点击事件
            for(var i = 0;i<li.length-4;i++){
                li[i+2].index = i+2;
                li[i+2].onclick = function(){
                    Background(this.index);
                    document.getElementById("demo").innerHTML = "第&nbsp" + i-"4" + "&nbsp页";
                }
            }
    //把所有的分页背景去掉，给指定的分页添加背景颜色
            function Background(num){
                for(var i = 0;i<li.length;i++){
                    li[i].className = li[i].className.replace('background','');
                    li[num].className = 'background';
                }
            }
    // 给li 写内容
        content(num01);
            function content(number){
                for(var i=0;i<li.length-4;i++){
                    li[i+2].innerHTML = number;
                    if(number>="5"){document.getElementById("demo").innerHTML = "第&nbsp" + number + "&nbsp页";}
                    number++; 
                }
            }        

//vue
   
        
var ap = new Vue({
  el:'#ap',
  data: {
 
    author:'@name()',
    message: '这是一个作者',
  }
})

    




//mockjs


//调用mock方法模拟数据
Mock.mock(
    'http://mockjs', {
                    //星级
                    'string|1-5': "★",
                    // 书名
                    title:'@title(1,5)',
          			// 作者
          		   author:'@name()',
    }
);

//ajax请求
$("#mockjs").click(function(){
    $.ajax({
        url        : "http://mockjs",    //请求的url地址
        dataType   : "json",   //返回格式为json
        async      : true, //请求是否异步，默认为异步，这也是ajax重要特性
        data       : {},    //参数值
        type       : "post",   //请求方式
        beforeSend : function() {
            //请求前的处理
        },
        success: function(req) {
            //请求成功时处理
            console.log(req);
        },
        complete: function() {
            //请求完成的处理
        },
        error: function() {
            //请求出错处理
        }
    });
});

$.ajax({
    url: 'http://test.com',
    type: '',
    dataType: 'json',
    data: {
      account: 888,
      pwd: 'abc123'
    }
}).done(function(data, status, xhr) {
    console.log(JSON.stringify(data, null, 4));
});
       

//</script>详情页弹出（未加载）

          function ondetails(){
              document.getElementById("details").style.display="block";}
          function closedetails(){
              document.getElementById("details").style.display="none";
          }

    var title = console.read(document.title)
    window.onload = function() {
        var author = document.getElementById("author");
        author.innerHTML="titleaa"
 
   }
