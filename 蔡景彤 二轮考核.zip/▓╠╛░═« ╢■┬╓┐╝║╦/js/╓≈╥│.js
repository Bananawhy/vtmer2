//弹出登录框和关闭登录框
function loginkuang(){
    document.getElementById("icon").style.display="block";
    }
function guanbi(){
    document.getElementById("icon").style.display="none";}

//loading动画
function login(){
    document.getElementById("loading").style.display="block";
    document.getElementsByTagName("li")[0].style.backgroundColor="#edf0f3";{
    setTimeout(function(){
        document.getElementsByTagName("li")[1].style.backgroundColor="#edf0f3";
        document.getElementsByTagName("li")[0].style.backgroundColor="#3d3d3d";
        document.getElementsByTagName("li")[2].style.backgroundColor="#3d3d3d";{
            setTimeout(function(){
                document.getElementsByTagName("li")[2].style.backgroundColor="#edf0f3";
                document.getElementsByTagName("li")[1].style.backgroundColor="#3d3d3d";
                document.getElementsByTagName("li")[0].style.backgroundColor="#3d3d3d";{
                    setTimeout(function(){
                        document.getElementsByTagName("li")[0].style.backgroundColor="#edf0f3";
                        document.getElementsByTagName("li")[1].style.backgroundColor="#3d3d3d";
                        document.getElementsByTagName("li")[2].style.backgroundColor="#3d3d3d";{
                            setTimeout(function(){
                                document.getElementsByTagName("li")[1].style.backgroundColor="#edf0f3";
                                document.getElementsByTagName("li")[0].style.backgroundColor="#3d3d3d";
                                document.getElementsByTagName("li")[2].style.backgroundColor="#3d3d3d";
                            },1000);
                        }
                    },1000);
                }
            },1000);
        }
    },1000);} 
    //右上角小人更换为用户名
    setTimeout(function(){
        document.getElementById("loading").style.display="none";
        document.getElementById("people").style.display="none";
        document.getElementById("changepeople").style.display="block";
        document.getElementById("icon").style.display="none";
    },5000);
}

     
//传入 event  
function EnterPress(e){ 
    var e = e || window.event;  
    //按回车实现搜索
        if(e.keyCode == 13){   
            //实现搜索功能
            function search(){
            }   
        }  }
